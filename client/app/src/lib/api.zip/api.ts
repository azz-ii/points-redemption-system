// API Configuration and Service Layer
// Use relative URLs to match the login flow (cookies are set for the same origin)
const API_BASE_URL = "/api";

// Backend API Response Types
export interface CatalogueItem {
  id: number;
  reward: string | null;
  item_name: string;
  description: string;
  purpose: string;
  specifications: string;
  legend: "COLLATERAL" | "GIVEAWAY" | "ASSET" | "BENEFIT";
  added_by: number | null;
  is_archived: boolean;
  date_archived: string | null;
  archived_by: number | null;
}

export interface Variant {
  id: number;
  catalogue_item: CatalogueItem;
  catalogue_item_id: number;
  item_code: string;
  option_description: string | null;
  points: string;
  price: string;
  image_url: string | null;
}

export interface CatalogueItemsResponse {
  items: Variant[];
}

// Frontend Display Types
export interface RedeemItemData {
  id: string;
  name: string;
  points: number;
  image: string;
  category: string;
}

export interface UserProfile {
  id: number;
  username: string;
  full_name: string;
  email: string;
  position: string;
  is_activated: boolean;
  is_banned: boolean;
  uses_points: boolean;
  points: number;
  profile: {
    uses_points: boolean;
    points: number;
  };
}

// Map backend legend to frontend category
const legendToCategoryMap: Record<string, string> = {
  COLLATERAL: "Collateral",
  GIVEAWAY: "Giveaway",
  ASSET: "Asset",
  BENEFIT: "Benefit",
};

// Transform backend variant data to frontend format
export function transformVariantToRedeemItem(variant: Variant): RedeemItemData {
  console.log("[API] Transforming variant:", variant);
  
  // Parse points - handle both numeric and formula strings
  let pointsValue = 0;
  try {
    // Try to parse as number first
    const parsed = parseFloat(variant.points);
    if (!isNaN(parsed)) {
      pointsValue = parsed;
    } else {
      console.warn(`[API] Could not parse points value: ${variant.points}`);
      pointsValue = 0;
    }
  } catch (error) {
    console.error("[API] Error parsing points:", error);
    pointsValue = 0;
  }

  // Use placeholder image if no image_url provided
  const imageUrl = variant.image_url && variant.image_url.trim() !== "" 
    ? variant.image_url 
    : "/images/tshirt.png";

  console.log(`[API] Image URL for ${variant.catalogue_item.item_name}: ${imageUrl}`);

  // Get category from legend
  const category = legendToCategoryMap[variant.catalogue_item.legend] || variant.catalogue_item.legend;

  const transformed: RedeemItemData = {
    id: variant.id.toString(),
    name: variant.catalogue_item.item_name,
    points: pointsValue,
    image: imageUrl,
    category: category,
  };

  console.log("[API] Transformed item:", transformed);
  return transformed;
}

// Fetch catalogue items from backend
export async function fetchCatalogueItems(): Promise<RedeemItemData[]> {
  console.log("[API] Fetching catalogue items from:", `${API_BASE_URL}/catalogue/`);
  
  try {
    const response = await fetch(`${API_BASE_URL}/catalogue/`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include", // Include cookies for session authentication
    });

    console.log("[API] Response status:", response.status);
    console.log("[API] Response ok:", response.ok);

    if (!response.ok) {
      const errorText = await response.text();
      console.error("[API] Error response:", errorText);
      throw new Error(`Failed to fetch catalogue items: ${response.status} ${response.statusText}`);
    }

    const data: CatalogueItemsResponse = await response.json();
    console.log("[API] Received data:", data);
    console.log("[API] Number of items:", data.items?.length || 0);

    if (!data.items || !Array.isArray(data.items)) {
      console.error("[API] Invalid response format - items not found or not an array");
      throw new Error("Invalid response format from server");
    }

    // Filter out archived items
    const activeItems = data.items.filter(variant => !variant.catalogue_item.is_archived);
    console.log("[API] Active (non-archived) items:", activeItems.length);

    // Transform to frontend format
    const transformedItems = activeItems.map(transformVariantToRedeemItem);
    console.log("[API] Transformed items:", transformedItems);

    return transformedItems;
  } catch (error) {
    console.error("[API] Error fetching catalogue items:", error);
    if (error instanceof Error) {
      console.error("[API] Error message:", error.message);
      console.error("[API] Error stack:", error.stack);
    }
    throw error;
  }
}

// Fetch current user profile
export async function fetchCurrentUser(): Promise<UserProfile> {
  console.log("[API] Fetching current user profile from:", `${API_BASE_URL}/users/me/`);
  
  try {
    const response = await fetch(`${API_BASE_URL}/users/me/`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include", // Include cookies for session authentication
    });

    console.log("[API] User profile response status:", response.status);
    console.log("[API] User profile response ok:", response.ok);

    if (!response.ok) {
      const errorText = await response.text();
      console.error("[API] Error response:", errorText);
      throw new Error(`Failed to fetch user profile: ${response.status} ${response.statusText}`);
    }

    const userData: UserProfile = await response.json();
    console.log("[API] Received user profile:", userData);
    console.log("[API] User points:", userData.points || userData.profile?.points);

    return userData;
  } catch (error) {
    console.error("[API] Error fetching current user:", error);
    if (error instanceof Error) {
      console.error("[API] Error message:", error.message);
      console.error("[API] Error stack:", error.stack);
    }
    throw error;
  }
}
